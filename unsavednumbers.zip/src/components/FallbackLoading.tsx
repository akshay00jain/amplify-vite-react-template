const FallbackLoading = () => {
  return <div></div>
}

export default FallbackLoading
